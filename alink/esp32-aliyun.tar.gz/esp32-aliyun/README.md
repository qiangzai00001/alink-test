# IoT_SDK_V2.01  

## SDK使用准备  
登录 IoT 控制台获得相关配置信息。

- 创建产品得到 productKey (产品 key)；
- 选择设备管理，在产品下添加设备得到 deviceName (设备名称)、 deviceSecret (设备密钥)；
- 查看设备的Topic

然后在 main 文件中进行上述信息填充设置。