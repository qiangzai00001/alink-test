#SDK使用准备

登录[IoT控制台](http://iot.console.aliyun.com)获得相关配置信息。

   + 创建产品得到productKey(产品key);
   + 选择设备管理，在产品下添加设备得到deviceName(设备名称)、deviceID(设备唯一ID)、deviceSecret(设备密钥)；
   + 查看设备的Topic

具体请参考[控制台使用手册](~~42714~~)文档中的`创建产品`、`添加设备`以及`获取设备Topic`部分。
