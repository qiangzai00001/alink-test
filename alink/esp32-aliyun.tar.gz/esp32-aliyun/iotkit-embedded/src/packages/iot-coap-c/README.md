#### Alibaba IoT-CoAP-c: A C implementation of the Constrained Application Protocol (RFC 7252).####
### ABOUT IoT-CoAP-c ###
### PACKAGE CONTENTS  ###
### LICENSE INFORMATION ###
